function ACTS = get_ACTS_features(Hb_O,Hb_R)
% GET_ACTS_FEATURES   The extraction of brain ACTS features
%
%  ACTS = get_ACTS_features(Hb_O,Hb_R);
%
%  The ACTS features quantify the brain variations at three brain functional
%  level, including brain regional activation, brain hemodynamic states, and
%  brain functional connectivity.
%
%  Inputs:
%      Hb_O: Concentration changes of oxyhemoglobin. The size of Hb_O is [m,n], 
%            where m is the signal length (time*fs), n is the channel number
%      Hb_R: Concentration changes of deoxyhemoglobin. The size of Hb_R is
%            the same as Hb_O 
%
%  Outputs:
%      ACTS: Brain activation-transition-spectrum features

% Parameters
num_channel = size(Hb_O,2);
fs = 11;
time_walking = 35;

% Calculating temporal features of brain regional activation 
fea_temporal = [];
for ic = 1:num_channel
    % The process of calculating temporal features
    fea_mean = mean(Hb_O(:,ic));
    fea_var = var(Hb_O(:,ic));
    fea_peak = max(Hb_O(:,ic));
    slope = polyfit(0:1/fs:time_walking,Hb_O(:,ic),1); fea_slope = slope(1);
    fea_kurt = kurtosis(Hb_O(:,ic));
    fea_skew = skewness(Hb_O(:,ic));
    
    % Temporal features of brain regional activation 
    fea_temporal = [fea_temporal fea_mean fea_var fea_peak fea_kurt fea_skew];
end

% Calculating transition features of brain hemodynamic states 
fea_transition = [];
for ic = 1:num_channel
    one_O = Hb_O(:,ic); one_R = Hb_R(:,ic);
    fea_ace = get_ace_feature(one_R,one_O,fs,time_walking);
    fea_angle = get_angle_feature(one_O,one_R,fs,time_walking);
    fea_str = fea_ace * fea_angle;
    fea_transition = [fea_transition fea_ace fea_angle fea_str];
end

% Calculating graph spectrums of brain functional connectivity
n_samples = size(Hb_O,1);
[~,~,matrix_used]=fastfc_ps(Hb_O,n_samples*.1,1);
for ici = 1:num_channel
   matrix_used(ici,ici) = 0; 
end
G = gsp_graph(matrix_used);
G = gsp_compute_fourier_basis(G);
fea_spectrum = (G.e)';

ACTS = [fea_temporal fea_transition fea_spectrum];

