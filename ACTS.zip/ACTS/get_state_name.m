function state_name = get_state_name(HbO_channel_time,HbR_channel_time)
if (HbO_channel_time>0) && (HbR_channel_time<0)
    state_name = 'expand';
elseif (HbO_channel_time<0) && (HbR_channel_time>0)
    state_name = 'hypo';
else
    state_name = 'inter';
end