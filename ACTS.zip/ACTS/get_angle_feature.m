function fea_angle = get_angle_feature(one_O,one_R,fs,time_walking)

t_time = 0:1/fs:time_walking;
three_d_signal = [one_R,one_O,t_time'];

% length 
num_t = length(t_time);

% Setting factor
state_factor = [];
for itc = 1:(num_t-1)
    % Geeting state name
    state_current = get_state_name(one_O(itc),one_R(itc));
    state_next = get_state_name(one_O(itc+1),one_R(itc+1));
    if strcmp(state_current,state_next)
        state_factor = [state_factor;3];
    else
        state_factor = [state_factor;1.5];
    end
    
end

% Calculating angle
angle_collect = [];
for ita = 1:(num_t-1)
    % Two signals
    signal_1 = three_d_signal(ita,:);
    signal_2 = three_d_signal(ita+1,:);
    
    % Length
    L1 = (signal_1(1)^2+signal_1(2)^2+signal_1(3)^2)^0.5;
    L2 = (signal_2(1)^2+signal_2(2)^2+signal_2(3)^2)^0.5;
    
    value = (  signal_1(1)*signal_2(1) + signal_1(2)*signal_2(2) + signal_1(3)*signal_2(3) )/(L1*L2);
    angle_one = acos(value);
    angle_collect = [angle_collect;abs(angle_one)];
    
end
vel_matrix = angle_collect/(1/11);
fea_angle = mean(vel_matrix.*state_factor);