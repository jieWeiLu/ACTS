function fea_ace = get_ace_feature(one_R,one_O,fs,time_walking)

t_time = 0:1/fs:time_walking;
three_d_signal = [one_R,one_O,t_time'];

% Length
num_t = length(t_time);

% Setting factor
state_factor_1 = [];
for itc = 1:(num_t-2)
    % Geeting state name
    state_current = get_state_name(one_O(itc),one_R(itc));
    state_next = get_state_name(one_O(itc+1),one_R(itc+1));
    state_next_next = get_state_name(one_O(itc+2),one_R(itc+2));
    
    if strcmp(state_current,state_next) && strcmp(state_next,state_next_next)
        state_factor_1 = [state_factor_1;9];
    elseif ~strcmp(state_current,state_next) && ~strcmp(state_current,state_next_next)
        state_factor_1 = [state_factor_1;1.5*1.5];
    else
        state_factor_1 = [state_factor_1;4.5];
    end
    
end

% Calculating distance
dis_matrix = [];
dis_fea = 0;
for ita = 1:(num_t-1)
    signal_1 = three_d_signal(ita,:);
    signal_2 = three_d_signal(ita+1,:);
    dis = sqrt(sum((signal_1-signal_2).^2));
    dis_fea = dis_fea + dis;
    
    dis_matrix = [dis_matrix;dis];
    
end

% Calculating acceleration
delta_t = 1/fs;
vel_matrix = dis_matrix/delta_t;
ace_matrix = [];
for iv = 1:length(vel_matrix)-1
    ace_one = abs(vel_matrix(iv+1)-vel_matrix(iv))/delta_t;
    ace_matrix = [ace_matrix;ace_one];
end
fea_ace = mean(ace_matrix.*state_factor_1);