System requirements:
MATLAB R2021a
GSPBOX 0.7.5

File:
get_ACTS_features.m -- extracting brain activation-transition-spectrum features
get_ace_feature.m -- calculating transition acceleration 
get_angle_feature.m -- calculating transition angel
get_state_name.m -- obtaining hemodynamic state
fastfc_ps.mexw64 and libfftw3f-3.dll: calculating phase lag index

Instructions for use
It has been shown in the code.
